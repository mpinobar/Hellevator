MB-Demonic_Tale - Ornate Font by ModBlackmoon. [Photoshop, based on Roman Capitals]

INFO: 
Incl. English, European and Cyrillic letters and Numbers.

LICENSE: 
Free for personal and commercial use. No modify!

Designed: May 2012.
Author: ModBlackmoon
WEB: modblackmoon.narod.ru / modblackmoon.deviantart.com